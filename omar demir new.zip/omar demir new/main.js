// ============================================
// LOADER
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    const loader = document.getElementById('loader');
    if (loader) {
        setTimeout(function() {
            loader.classList.add('hidden');
        }, 800);
    }
});

// ============================================
// HAMBURGER MENU
// ============================================
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu on link click
    navMenu.querySelectorAll('a').forEach(function(link) {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
}

// ============================================
// HEADER SCROLL EFFECT
// ============================================
const header = document.getElementById('header');

window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// ============================================
// SCROLL TO TOP BUTTON
// ============================================
const scrollBtn = document.getElementById('scrollTop');

if (scrollBtn) {
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            scrollBtn.classList.add('visible');
        } else {
            scrollBtn.classList.remove('visible');
        }
    });

    scrollBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// ============================================
// ON SCROLL ANIMATIONS
// ============================================
const animateElements = document.querySelectorAll('.animate-on-scroll');

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
});

animateElements.forEach(function(el) {
    observer.observe(el);
});

// ============================================
// COUNTER ANIMATION
// ============================================
const counters = document.querySelectorAll('.stat-number[data-count]');

counters.forEach(function(counter) {
    const target = parseInt(counter.getAttribute('data-count'));
    let current = 0;
    const increment = target / 50;

    const updateCounter = function() {
        current += increment;
        if (current < target) {
            counter.textContent = Math.ceil(current);
            setTimeout(updateCounter, 30);
        } else {
            counter.textContent = target + '+';
        }
    };

    const observerCounter = new IntersectionObserver(function(entries) {
        if (entries[0].isIntersecting) {
            updateCounter();
            observerCounter.disconnect();
        }
    });

    observerCounter.observe(counter);
});